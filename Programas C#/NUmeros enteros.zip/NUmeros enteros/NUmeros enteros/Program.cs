﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NUmeros_enteros
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3;
            //Entrada
            Console.WriteLine("Digite el primer numero: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Digite el segundo numero: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Digite el tercer numero: ");
            num3 = Convert.ToInt32(Console.ReadLine());
            //Proceso
            int numeroMayor = num1;
            if (num2 > numeroMayor)
            {
                numeroMayor = num2;
            }
            if (num3 > numeroMayor)
            {
                numeroMayor = num3;
            }
            int numeroMenor = num1;
            if (num2 < numeroMenor)
            {
                numeroMenor = num2;
            }
            if (num3 < numeroMenor)
            {
                numeroMenor = num3;
            }
            int numeroIntermedio = num1;
            if (num1 > numeroMenor && num1<numeroMayor)
            {
                numeroIntermedio = num1;
            }
            Console.WriteLine("El numero menor es: "+numeroMenor);
            Console.WriteLine("El numero intermedio es: " + numeroIntermedio);
            Console.WriteLine("El numero mayor es: " + numeroMayor);
        }
            }

        }
