﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Triangulos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int l1, l2,l3;
            Console.WriteLine("Dime el lado 1: ");
            l1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Dime el lado 1: ");
            l2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Dime el lado 1: ");
            l3 = Convert.ToInt32(Console.ReadLine());

            if (l1 == l2 && l1 == l3)
            {
                Console.WriteLine("Triángulo Equilatero");
            }
            if (l1 == l2 || l1 == l3 || 12 ==13)
            {
                Console.WriteLine("Triángulo Isóceles");
            }
            if (l1 != l2 || l1 != l3 || 12 != 13)
            {
                Console.WriteLine("Triángulo Escaleno");
            }
        }
    }
}
