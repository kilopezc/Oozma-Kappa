﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Proyecto
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Posiciones
            int posX = 100;
            int posY = 100;

            //Color de fondo Login
            Console.BackgroundColor = ConsoleColor.Magenta;
            Console.WriteLine("Kenneth López | 23 | IVB");

            //Variables
            string user = "prograFacil", capUser;
            int contra = 123;

            Boolean x = true;//Variable del login
            Boolean z = true;//Variable del ciclo del menù

            //Variable para las opciones
            int opcion;

            //Ingresar al sistema
            while (x != false)
            {

                //Solicitar y leer usuario
                Console.Clear();
                Console.SetCursorPosition(posX - 45, posY - 90);//Posicioón Texto
                Console.Write("Usuario: ");
                capUser = Console.ReadLine();

                //Evaluar el usuario
                if (capUser.Equals(user))
                {
                    //Solicitar Contraseña
                    Console.Clear();
                    Console.SetCursorPosition(posX - 45, posY - 90);//Posicioón Texto
                    Console.Write("Password: ");
                    int capContra = Convert.ToInt32(Console.ReadLine());

                    //Evaluar Contraseña
                    if (capContra == contra)
                    {
                        //Mostrar un cargando como bienvenida
                        Console.Clear();
                        Console.SetCursorPosition(posX - 45, posY - 90);
                        Console.WriteLine("Cargando...");
                        Console.SetCursorPosition(posX - 45, posY - 89);
                        for (int i = 0; i < 26; i++)
                        {
                            Console.Write((char)124);
                            Thread.Sleep(500);

                        }

                        //Ingresar al Menù principal
                        do
                        {
                            //Menú
                            Console.BackgroundColor = ConsoleColor.DarkBlue;//Color de fondo Menú
                            Console.ForegroundColor = ConsoleColor.White;//Color de letra
                            Console.Clear();
                            Console.SetCursorPosition(posX - 45, posY - 90);
                            Console.WriteLine("Menú Principal");
                            Console.SetCursorPosition(posX - 45, posY - 88);
                            Console.WriteLine("1. Lección 25");
                            Console.SetCursorPosition(posX - 45, posY - 87);
                            Console.WriteLine("2. Lección 26");
                            Console.SetCursorPosition(posX - 45, posY - 86);
                            Console.WriteLine("3. Lección 27");
                            Console.SetCursorPosition(posX - 45, posY - 85);
                            Console.WriteLine("4. Lección 28");
                            Console.SetCursorPosition(posX - 45, posY - 84);
                            Console.WriteLine("5. Propuesto 1");
                            Console.SetCursorPosition(posX - 45, posY - 83);
                            Console.WriteLine("6. Propuesto 2");
                            Console.SetCursorPosition(posX - 45, posY - 82);
                            Console.WriteLine("7. Salir");

                            //Solicitar opción
                            Console.SetCursorPosition(posX - 45, posY - 81);
                            Console.Write("Digite Opción: [ ]");
                            Console.SetCursorPosition(posX - 27, posY - 81);
                            opcion = Convert.ToInt32(Console.ReadLine());

                            //Ingresar a las opciones
                            switch (opcion)
                            {
                                case 1:
                                    Console.BackgroundColor = ConsoleColor.DarkMagenta;
                                    Console.Clear();
                                    Console.SetCursorPosition(posX - 45, posY - 90);
                                    Console.Write("Leccion 25");

                                    Boolean ing = true;
                                    int carro = 1;

                                    do
                                    {
                                        Console.ReadKey();
                                        Console.SetCursorPosition(posX - 60, posY - 88);
                                        Console.WriteLine("Ahora hay " + carro + " auto en el estacionamiento");
                                        Console.SetCursorPosition(posX - 60, posY - 87);
                                        Console.WriteLine("Quedan " + (200 - carro) + " lugares libres");
                                        carro++;

                                        if (carro == 201)
                                        {
                                            ing = false;
                                            Console.SetCursorPosition(posX - 60, posY - 86);
                                            Console.WriteLine("El estacionamiento está lleno");
                                        }
                                        Console.WriteLine();
                                    } while (ing != false);
                                    Console.ReadKey();
                                    break;
                                case 2:
                                    Console.BackgroundColor = ConsoleColor.DarkMagenta;
                                    Console.Clear();
                                    Console.SetCursorPosition(posX - 45, posY - 90);
                                    Console.Write("Leccion 26");

                                    int num = 1;

                                    Console.SetCursorPosition(posX - 60, posY - 88);
                                    Console.Write("Digite un numero mayor que 1: ");
                                    Console.SetCursorPosition(posX - 60, posY - 87);
                                    string dato = Console.ReadLine();
                                    int numUsuario = Convert.ToInt32(dato);

                                    Console.WriteLine("\nLa lista de numero es: ");

                                    do
                                    {
                                        Console.WriteLine(num);
                                        num++;
                                    } while (num != numUsuario + 1);
                                    Console.ReadKey();
                                    break;
                                case 3:
                                    Console.BackgroundColor = ConsoleColor.DarkMagenta;
                                    Console.Clear();
                                    Console.SetCursorPosition(posX - 45, posY - 90);
                                    Console.Write("Lección 27");
                                    int numero = 0;
                                    int salir = 0;
                                    do
                                    {
                                        Console.SetCursorPosition(posX - 60, posY - 88);
                                        Console.WriteLine("Ingresa un número");
                                        numero = int.Parse(Console.ReadLine());
                                        for (int i = 1; i <= 10; i++)
                                        {
                                            Console.WriteLine(numero + "*" + i + "=" + numero * i);
                                        }

                                        Console.WriteLine("¿Deseas continuar? Presiona cualquiera tecla para continuar");
                                        Console.WriteLine("De lo contrario presiona la tecla 1");
                                        salir = int.Parse(Console.ReadLine());
                                        Console.Clear();
                                    } while (salir != 1);
                                    break;
                                case 4:
                                    Console.BackgroundColor = ConsoleColor.DarkMagenta;
                                    Console.Clear();
                                    Console.SetCursorPosition(posX - 45, posY - 90);
                                    Console.Write("Leccion 28");

                                    int stri = 0;
                                    int din = 0;
                                    int tot = 0;

                                    do
                                    {
                                        Console.WriteLine("Tienes " + stri + " strike(s)");
                                        Console.WriteLine("Ingresa la cantidad de dinero ganado");


                                        din = int.Parse(Console.ReadLine());
                                        if (din == 0)
                                        {
                                            stri++;
                                        }
                                        else
                                        {
                                            tot += din;
                                        }
                                    } while (stri < 3);

                                    Console.WriteLine("Game Over");
                                    break;
                                case 5:
                                    Console.BackgroundColor = ConsoleColor.DarkMagenta;
                                    Console.Clear();
                                    Console.SetCursorPosition(posX - 40, posY - 90);
                                    Console.Write("Propuesto 1");

                                    int precioNiño = 10;
                                    int precioAdulto = 15;
                                    int boletosVendidos = 0;
                                    int totalCobrado = 0;
                                    bool continuar = true;

                                    while (continuar)
                                    {
                                        int tipoDeBoleto;
                                        Console.SetCursorPosition(posX - 60, posY - 89);
                                        Console.WriteLine("Ingrese el tipo de boleto");
                                        Console.SetCursorPosition(posX - 60, posY - 88);
                                        Console.WriteLine("1. Niño $10");
                                        Console.SetCursorPosition(posX - 60, posY - 87);
                                        Console.WriteLine("2. Adulto $15");
                                        Console.SetCursorPosition(posX - 60, posY - 86);
                                        tipoDeBoleto = int.Parse(Console.ReadLine());

                                        if (tipoDeBoleto == 1)
                                        {
                                            boletosVendidos++;
                                            totalCobrado += precioNiño;
                                        }
                                        else if (tipoDeBoleto == 2)
                                        {
                                            boletosVendidos++;
                                            totalCobrado += precioAdulto;
                                        }
                                        else
                                        {
                                            Console.WriteLine("Opción inválida.");
                                        }
                                        Console.SetCursorPosition(posX - 60, posY - 84);
                                        Console.WriteLine("El número de boletos vendidos fue: " + boletosVendidos);
                                        Console.SetCursorPosition(posX - 60, posY - 83);
                                        Console.WriteLine("El total cobrado fue: " + totalCobrado);
                                        Console.SetCursorPosition(posX - 60, posY - 82);
                                        Console.WriteLine("¿Desea continuar vendiendo boletos? (1 para sí, 2 para no): ");
                                        Console.SetCursorPosition(posX - 60, posY - 81);
                                        int respuesta = int.Parse(Console.ReadLine());

                                        if (respuesta == 2)
                                        {
                                            continuar = false;
                                        }
                                    }
                                    break;
                                case 6:
                                    Console.BackgroundColor = ConsoleColor.DarkMagenta;
                                    Console.Clear();
                                    Console.SetCursorPosition(posX - 45, posY - 90);
                                    Console.WriteLine("Propuesto 2");

                                    int denominacion100 = 100;
                                    int cantBilletes100 = 0;
                                    int totalDinero = 0;
                                    char opc;

                                    do
                                    {
                                        do
                                        {
                                            Console.WriteLine("Ingresa la denominación del billete(o 's' para salir): ");


                                            string entrada = Console.ReadLine().ToLower();
                                            if (entrada == "s")
                                            {
                                                break;
                                            }
                                            if (!int.TryParse(entrada, out int denominacion))
                                            {
                                                Console.WriteLine("Por favor, ingresa un número válido o 's' para salir.");
                                                continue;
                                            }
                                            totalDinero += denominacion;
                                            if (denominacion == denominacion100)
                                            {
                                                cantBilletes100++;
                                            }
                                        } while (true);
                                        Console.Clear();
                                        Console.SetCursorPosition(posX - 45, posY - 90);
                                        Console.WriteLine($"Cantidad de billetes de {denominacion100}: {cantBilletes100} ");
                                        Console.SetCursorPosition(posX - 45, posY - 90);
                                        Console.WriteLine($"Total de dinero:${totalDinero} ");
                                        Console.SetCursorPosition(posX - 45, posY - 90);
                                        Console.WriteLine("¿Deseas ingresar más billetes? (S / N)");


                                        opc = Console.ReadKey().KeyChar;
                                        Console.WriteLine();
                                        cantBilletes100 = 0;
                                        totalDinero = 0;

                                    } while (char.ToLower(opc) == 's');
                                    Console.WriteLine("Gracias por usar el programa, Presiona cualquier tecla para salir...");
                                    Console.ReadKey();
                                    break;
                                case 7:
                                    Console.BackgroundColor = ConsoleColor.Red;
                                    Console.Clear();
                                    Console.SetCursorPosition(posX - 45, posY - 90);
                                    Console.Write("Salir del Sistema 1/si o 0/no [ ]");
                                    Console.SetCursorPosition(posX - 45, posY - 89);
                                    int res = Convert.ToInt32(Console.ReadLine());
                                    if (res == 1)
                                    {
                                        z = false;
                                        x = false;
                                    }
                                    else
                                    {
                                        Console.Clear();
                                        Console.SetCursorPosition(posX - 45, posY - 90);
                                        Console.WriteLine("Regresando al Menu Principal...");


                                        Console.SetCursorPosition(posX - 45, posY - 89);
                                        for (int i = 0; i < 26; i++)
                                        {
                                            Console.Write((char)124);
                                            Thread.Sleep(300);
                                        }
                                    }
                                    break;
                                default:
                                    Console.Clear();
                                    Console.SetCursorPosition(posX - 45, posY - 82);
                                    Console.Write("Opcion Invalida!!!");
                                    Thread.Sleep(300);
                                    break;
                            }
                        }
                        while (z != false);
                        x = false;
                    }
                    else
                    {
                        Console.SetCursorPosition(posX - 45, posY - 89);
                        Console.WriteLine("Contraseña Incorrecta!!");
                        Thread.Sleep(2000);
                    }
                }
                else
                {
                    Console.SetCursorPosition(posX - 45, posY - 89);
                    Console.WriteLine("Usuario Incorrecto!!");
                    Thread.Sleep(2000);
                }
            }
            Console.Clear();
            Console.SetCursorPosition(posX - 45, posY - 90);
            Console.WriteLine("Saliendo del sistema!!");
            Console.SetCursorPosition(posX - 45, posY - 89);
            for (int i = 1; i < 25; i++)
            {
                Console.Write((char)124);
                Thread.Sleep(500);
            }
        }
    }
}

