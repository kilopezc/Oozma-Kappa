﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Estaciones1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numDia, numMes;
            Console.WriteLine("Digite numero del dia del 1 al 31");
            numDia = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Digite numero del mes del 1 al 12");
            numMes = Convert.ToInt32(Console.ReadLine());

            if (numDia >= 21 && numMes == 3)
            {
                Console.WriteLine("Primavera");
            }
            else if (numDia >= 21 && numMes == 6)
            {
                Console.WriteLine("Verano");
            }
            else if (numDia >= 21 && numMes == 9)
            {
                Console.WriteLine("Otoño");
            }
            else if (numDia >= 21 && numMes == 12)
            {
                Console.WriteLine("Invierno");
            }
        }
    }
}
