﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G2_EJER3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Inicio
            //Variables
            int a, b, c;
            double x1=0, x2=0;
            //Entrada
            Console.WriteLine("Digite el valor de a");
            a = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite el valor de b");
            b = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite el valor de c");
            c = int.Parse(Console.ReadLine());
            //Proceso
            x1 = ((-2 * b) + Math.Sqrt(Math.Pow(b, 2) - (4 * a * c))) / (2 * a);
            x2 = ((-2 * b) - Math.Sqrt(Math.Pow(b, 2) - (4 * a * c))) / (2 * a);
            //Salida
            Console.WriteLine("El resultado para x1 es" + x1);
            Console.WriteLine("El resultado para x2 es " + x2);
        }
    }
}
