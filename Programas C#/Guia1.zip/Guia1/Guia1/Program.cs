﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Guia1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Inicio
            //Variables
            int numero,producto;
            //Entrada
            Console.WriteLine("Digite un numero: ");
            numero=int.Parse(Console.ReadLine());
            //Proceso
            producto = (numero * 100);
            //Salida 
            Console.WriteLine("El producto del numero multiplicado por 100 es: " + producto);
        }
    }
}
