﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G4_IVUnidad
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Crear la  matriz 
            int[,] edades = new int[3, 3];

            //Solicitar  ingresar las edades 
            Console.BackgroundColor = ConsoleColor.Cyan;
            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            Console.WriteLine("Ingrese las edades de los alumnos:");

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("Edad del alumno: ", i + 1, j + 1);
                    edades[i, j] = int.Parse(Console.ReadLine());
                }
            }

            //Mostrar la matriz con las edades y si los alumnos son mayores o menores de edad
            Console.WriteLine("\n");

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}-{1} ", edades[i, j], (edades[i, j] >= 18) ? "mayor" : "menor");
                }
                Console.WriteLine();
            }
        }
    }
}