﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G1_EJER2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Inicio
            //Variables
            double num1, num2, num3, promedio;
            //Entrada
            Console.WriteLine("Digite el primer numero");
            num1=int.Parse(Console.ReadLine());
            Console.WriteLine("Digite el segundo numero");
            num2=int.Parse(Console.ReadLine());
            Console.WriteLine("Digite el tercer numero");
            num3=int.Parse(Console.ReadLine());
            //Proceso
            promedio = (num1 + num2 + num3)/3;
            //Salida
            Console.WriteLine("El promedio de los 3 numeros es de: " + promedio);
        }
    }
}
