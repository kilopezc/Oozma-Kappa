﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace numeros
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Ingrese un número");
            num=int.Parse(Console.ReadLine());
            Console.WriteLine("");
            switch (num)
            {
                case 1:
                    Console.WriteLine("Tu nombre");
                    break;
                case 2:
                    Console.WriteLine("Nombre de tu maestro de Progra");
                    break;
                case 3: 
                    Console.WriteLine("Personaje que admires");
                    break;
                case 4:
                    Console.WriteLine("Tu canción favorita");
                    break;
                case 5:
                    Console.WriteLine("Nombre de un tu amigo");
                    break;
                case 6:
                    Console.WriteLine("Nombre de una tu amiga");
                    break;
                default:
                    Console.WriteLine("Número Inválido");
                    Console.WriteLine();
                    break;
            }

        }
    }
}