﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G2_EJER1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Inicio
            //Variables
            double numero, producto;
            //Entrada
            Console.WriteLine("Digite un numero");
            numero = int.Parse(Console.ReadLine());
            //Proceso
            producto = numero * 100;
            //Impresion del resultado
            Console.WriteLine("El resultado numero multiplicado por 100 es: " + producto);
            //Salida
        }
    }
}
