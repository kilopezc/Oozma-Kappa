﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clientes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numOpcion;
            Console.WriteLine("Bienvenido al servicio de buzon de voz");
            Console.WriteLine("Por favor ingrese el numero de opción");
            numOpcion=Convert.ToInt32(Console.ReadLine());
            if (numOpcion == 1)
            {
                Console.WriteLine("Bienvenido al Depto de Ventas");
                Console.WriteLine("Encargado: Jose Meza");
                Console.WriteLine("Email: jmeza@gmail.com");
            }
            else if (numOpcion == 2)
            {
                Console.WriteLine("Bienvenido al Depto de Recepción");
                Console.WriteLine("Encargado: Peter Goméz");
                Console.WriteLine("Email: pgomez@gmail.com");
            }
            else if (numOpcion == 3)
            {
                Console.WriteLine("Bienvenido al Depto de Dirección");
                Console.WriteLine("Encargado: Kenneth López");
                Console.WriteLine("Email: klopez@gmail.com");
            }
            else if (numOpcion == 4)
            {
                Console.WriteLine("Bienvenido al Depto de Compras");
                Console.WriteLine("Encargado: Jose Illescas");
                Console.WriteLine("Email: jillescas@gmail.com");
            }
            else {
                Console.WriteLine("Opción Invalida");
                    }
        }
    }
}
